import java.util.Arrays;

public class AnagramChecker {
        public static void main(String[] args) {
            String str1 = "software";
            String str2 = "swear ";

            boolean isAnagram = checkIfAnagram(str1, str2);

            if (isAnagram) {
                System.out.println("\"" + str1 + "\" and \"" + str2 + "\" are anagrams.");
            } else {
                System.out.println("\"" + str1 + "\" and \"" + str2 + "\" are not anagrams.");
            }
        }

        public static boolean checkIfAnagram(String str1, String str2) {
            String processedStr1 = removeWhitespaceAndPunctuation(str1);
            String processedStr2 = removeWhitespaceAndPunctuation(str2);

            // Check if the lengths are equal
            if (processedStr1.length() != processedStr2.length()) {
                return false;
            }

            // Convert the processed strings to lowercase character arrays
            char[] charArray1 = processedStr1.toLowerCase().toCharArray();
            char[] charArray2 = processedStr2.toLowerCase().toCharArray();

            // Sort the character arrays
            Arrays.sort(charArray1);
            Arrays.sort(charArray2);

            // Compare the sorted character arrays
            return Arrays.equals(charArray1, charArray2);
        }

        public static String removeWhitespaceAndPunctuation(String str) {
            // Remove whitespace and punctuation using regular expressions
            return str.replaceAll("[\\s\\p{Punct}]", "");
        }
    }




