public class City {
    private String code;
    private String name;
    private int population;
    private String countryCode;

    public City(String code, String name, int population, String countryCode) {
        this.code = code;
        this.name = name;
        this.population = population;
        this.countryCode = countryCode;
    }

    public String getCode() {
        return code;
    }

    public String getName() {
        return name;
    }

    public int getPopulation() {
        return population;
    }

    public String getCountryCode() {
        return countryCode;
    }

    @Override
    public String toString() {
        return name + " (Population: " + population + ")";
    }
}
