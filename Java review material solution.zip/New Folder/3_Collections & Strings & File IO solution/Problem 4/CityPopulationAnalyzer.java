import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.*;

public class CityPopulationAnalyzer {
    public static void main(String[] args) {
        // Step 1: Read the cities and countries files and store the data in lists
        List<City> cities = readCitiesFromFile("E:\\InteleJJ\\InteleJJ\\untitled3\\src\\Cities.txt");
        List<Country> countries = readCountriesFromFile("E:\\InteleJJ\\InteleJJ\\untitled3\\src\\Countries.txt");

        // Step 2: Create a map of country code to list of cities
        Map<String, List<City>> countryCityMap = createCountryCityMap(cities);

        // Step 3: Sort the cities within each country by population
        sortCitiesByPopulation(countryCityMap);

        // Step 4: Demonstrate getting the highest population city for a given country code
        String targetCountryCode = "USA";
        City highestPopulationCity = getHighestPopulationCityByCountry(countryCityMap, targetCountryCode);
        System.out.println("Highest population city for country " + targetCountryCode + ": " + highestPopulationCity);

        // Step 5a: Get the highest population city for each country
        Map<String, City> highestPopulationCitiesByCountry = getHighestPopulationCitiesByCountry(countryCityMap);
        System.out.println("\nHighest population cities by country:");
        for (Map.Entry<String, City> entry : highestPopulationCitiesByCountry.entrySet()) {
            System.out.println(entry.getKey() + ": " + entry.getValue());
        }

        // Step 5b: Get the highest population city by continent
        Map<String, City> highestPopulationCitiesByContinent = getHighestPopulationCitiesByContinent(countryCityMap, countries);
        System.out.println("\nHighest population cities by continent:");
        for (Map.Entry<String, City> entry : highestPopulationCitiesByContinent.entrySet()) {
            System.out.println(entry.getKey() + ": " + entry.getValue());
        }

        // Step 5c: Get the highest population capital
        String capitalFile = "CapitalCountryContinent.csv";
        City highestPopulationCapital = getHighestPopulationCapital(capitalFile, countryCityMap);
        System.out.println("\nHighest population capital: " + highestPopulationCapital);
    }

    // Step 1: Read cities from file and store in a list
    public static List<City> readCitiesFromFile(String filename) {
        List<City> cities = new ArrayList<>();

        try (BufferedReader reader = new BufferedReader(new FileReader(filename))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length >= 4) {
                    String code = parts[0].trim();
                    String name = parts[1].trim();
                    int population = Integer.parseInt(parts[2].trim());
                    String countryCode = parts[3].trim();
                    City city = new City(code, name, population, countryCode);
                    cities.add(city);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        return cities;
    }

    // Step 1: Read countries from file and store in a list
    public static List<Country> readCountriesFromFile(String filename) {
        List<Country> countries = new ArrayList<>();

        try (BufferedReader reader = new BufferedReader(new FileReader(filename))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length >= 2) {
                    String code = parts[0].trim();
                    String name = parts[1].trim();
                    Country country = new Country(code, name);
                    countries.add(country);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        return countries;
    }

    // Step 2: Create a map of country code to list of cities
    public static Map<String, List<City>> createCountryCityMap(List<City> cities) {
        Map<String, List<City>> countryCityMap = new HashMap<>();

        for (City city : cities) {
            String countryCode = city.getCountryCode();
            countryCityMap.computeIfAbsent(countryCode, k -> new ArrayList<>()).add(city);
        }

        return countryCityMap;
    }

    // Step 3: Sort the cities within each country by population
    public static void sortCitiesByPopulation(Map<String, List<City>> countryCityMap) {
        for (List<City> cityList : countryCityMap.values()) {
            cityList.sort(Comparator.comparingInt(City::getPopulation).reversed());
        }
    }

    // Step 4: Get the highest population city for a given country code
    public static City getHighestPopulationCityByCountry(Map<String, List<City>> countryCityMap, String countryCode) {
        List<City> cities = countryCityMap.get(countryCode);
        if (cities != null && !cities.isEmpty()) {
            return cities.get(0);
        } else {
            return null;
        }
    }

    // Step 5a: Get the highest population city for each country
    public static Map<String, City> getHighestPopulationCitiesByCountry(Map<String, List<City>> countryCityMap) {
        Map<String, City> highestPopulationCitiesByCountry = new HashMap<>();

        for (Map.Entry<String, List<City>> entry : countryCityMap.entrySet()) {
            List<City> cities = entry.getValue();
            if (!cities.isEmpty()) {
                City highestPopulationCity = cities.get(0);
                highestPopulationCitiesByCountry.put(entry.getKey(), highestPopulationCity);
            }
        }

        return highestPopulationCitiesByCountry;
    }

    // Step 5b: Get the highest population city by continent
    public static Map<String, City> getHighestPopulationCitiesByContinent(Map<String, List<City>> countryCityMap, List<Country> countries) {
        Map<String, String> countryContinentMap = readCountryContinentFromFile("countryContinent.csv");
        Map<String, City> highestPopulationCitiesByContinent = new HashMap<>();

        for (Country country : countries) {
            String countryCode = country.getCode();
            String continent = countryContinentMap.get(countryCode);
            if (continent != null) {
                List<City> cities = countryCityMap.get(countryCode);
                if (cities != null && !cities.isEmpty()) {
                    City highestPopulationCity = cities.get(0);
                    City currentHighestPopulationCity = highestPopulationCitiesByContinent.get(continent);
                    if (currentHighestPopulationCity == null || highestPopulationCity.getPopulation() > currentHighestPopulationCity.getPopulation()) {
                        highestPopulationCitiesByContinent.put(continent, highestPopulationCity);
                    }
                }
            }
        }

        return highestPopulationCitiesByContinent;
    }

    // Step 5c: Get the highest population capital
    public static City getHighestPopulationCapital(String capitalFile, Map<String, List<City>> countryCityMap) {
        Map<String, String> capitalCountryMap = readCapitalCountryFromFile(capitalFile);
        City highestPopulationCapital = null;

        for (List<City> cities : countryCityMap.values()) {
            for (City city : cities) {
                if (capitalCountryMap.containsKey(city.getCode())) {
                    if (highestPopulationCapital == null || city.getPopulation() > highestPopulationCapital.getPopulation()) {
                        highestPopulationCapital = city;
                    }
                }
            }
        }

        return highestPopulationCapital;
    }

    // Helper method to read country-continent mapping from file
    public static Map<String, String> readCountryContinentFromFile(String filename) {
        Map<String, String> countryContinentMap = new HashMap<>();

        try (BufferedReader reader = new BufferedReader(new FileReader(filename))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length >= 2) {
                    String countryCode = parts[0].trim();
                    String continent = parts[1].trim();
                    countryContinentMap.put(countryCode, continent);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        return countryContinentMap;
    }

    // Helper method to read capital-country mapping from file
    public static Map<String, String> readCapitalCountryFromFile(String filename) {
        Map<String, String> capitalCountryMap = new HashMap<>();

        try (BufferedReader reader = new BufferedReader(new FileReader(filename))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length >= 3) {
                    String capitalCode = parts[0].trim();
                    String countryCode = parts[1].trim();
                    capitalCountryMap.put(capitalCode, countryCode);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        return capitalCountryMap;
    }
}