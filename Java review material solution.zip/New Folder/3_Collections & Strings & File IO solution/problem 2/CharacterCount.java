import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class CharacterCount {
    public static void main(String[] args) {
        String filename = "E:\\InteleJJ\\InteleJJ\\untitled3\\src\\Mostafa1.txt"; // Assuming the file name is "Mostafa1.txt"
        char targetChar = 'e'; // Assuming the target character is 'e'

        try {
            int count = countCharacterOccurrences(filename, targetChar);
            System.out.println("The character '" + targetChar + "' appears " + count + " times in the file.");
        } catch (IOException e) {
            System.out.println("An error occurred while reading the file: " + e.getMessage());
        }
    }

    public static int countCharacterOccurrences(String filename, char targetChar) throws IOException {
        int count = 0;

        try (BufferedReader reader = new BufferedReader(new FileReader(filename))) {
            int currentChar;

            while ((currentChar = reader.read()) != -1) {
                if (Character.toLowerCase((char) currentChar) == Character.toLowerCase(targetChar)) {
                    count++;
                }
            }
        }

        return count;
    }
}