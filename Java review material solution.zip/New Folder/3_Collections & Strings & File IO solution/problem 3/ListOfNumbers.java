import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.Vector;

public class ListOfNumbers {
    private Vector<Integer> vector;
    private static final int SIZE = 10;

    public ListOfNumbers() {
        vector = new Vector<Integer>(SIZE);
        for (int i = 0; i < SIZE; i++) {
            vector.addElement(new Integer(i));
        }
    }

    public void readList(String filename) {
        BufferedReader reader = null;
        try {
            reader = new BufferedReader(new FileReader(filename));
            String line;
            while ((line = reader.readLine()) != null) {
                try {
                    int value = Integer.parseInt(line);
                    System.out.println("Read value: " + value);
                    vector.addElement(value);
                } catch (NumberFormatException e) {
                    System.err.println("Invalid number format: " + line);
                }
            }
        } catch (IOException e) {
            System.err.println("Error reading file: " + e.getMessage());
        } finally {
            if (reader != null) {
                try {
                    reader.close();
                } catch (IOException e) {
                    System.err.println("Error closing file: " + e.getMessage());
                }
            }
        }
    }

    public void displayList() {
        for (Integer value : vector) {
            System.out.print(value + " ");
        }
        System.out.println();
    }

    public static void main(String[] args) {
        ListOfNumbers list = new ListOfNumbers();
        list.readList("E:\\InteleJJ\\InteleJJ\\untitled3\\src\\Mostafa2.txt");
        list.displayList();
    }
}