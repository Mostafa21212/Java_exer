import java.util.ArrayList;
import java.util.List;

public class DeckOfCards {
    private List<PlayingCard> cards;

    public DeckOfCards() {
        cards = new ArrayList<>();
        initializeDeck();
    }

    private void initializeDeck() {
        Rank[] ranks = Rank.values();
        Suit[] suits = Suit.values();

        for (Suit suit : suits) {
            for (Rank rank : ranks) {
                PlayingCard card = new PlayingCard(rank, suit);
                cards.add(card);
            }
        }
    }

    public List<PlayingCard> getCards() {
        return cards;
    }
}