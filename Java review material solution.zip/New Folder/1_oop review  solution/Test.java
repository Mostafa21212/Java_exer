public class CardTest {
    public static void main(String[] args) {
        DeckOfCards deck = new DeckOfCards();
        List<PlayingCard> cards = deck.getCards();

        System.out.println("Deck of Cards:");
        for (PlayingCard card : cards) {
            System.out.println(card);
        }
    }
}