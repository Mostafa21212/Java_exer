import java.text.DecimalFormat;
import java.util.Scanner;

public class FloatingPointComparison {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter the first number: ");
        double number1 = scanner.nextDouble();

        System.out.print("Enter the second number: ");
        double number2 = scanner.nextDouble();

        boolean areEqual = compareFloatingPointNumbers(number1, number2);
        System.out.println(areEqual ? "The numbers are the same up to two decimal places."
                : "The numbers are different up to two decimal places.");
    }

    private static boolean compareFloatingPointNumbers(double number1, double number2) {
        DecimalFormat decimalFormat = new DecimalFormat("#.##");
        String formattedNumber1 = decimalFormat.format(number1);
        String formattedNumber2 = decimalFormat.format(number2);

        return formattedNumber1.equals(formattedNumber2);
    }
}